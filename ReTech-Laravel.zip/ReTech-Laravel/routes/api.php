<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\MarcaApiController;
use App\Http\Controllers\Api\MovilApiController;
use App\Http\Controllers\ProductosController;
use App\Http\Controllers\api\ModeloApiController;
use App\Http\Controllers\api\CarritoApiController;
use App\Models\Marca;
use App\Models\Modelo;
use App\Models\SistemaOperativo;
use App\Models\Movil;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Api\CheckoutApiController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::post('/login', function (Request $request) {
//     $credentials = $request->validate([
//         'email' => ['required', 'email'],
//         'password' => ['required'],
//     ]);

//     if (!Auth::attempt($credentials)) {
//         return response()->json(['message' => 'Credencials incorrectes'], 401);
//     }

//     $request->session()->regenerate();

//     return response()->json(Auth::user());
// })->withoutMiddleware(['throttle:api']);

Route::post('/login', function (Request $request) {
    $credentials = $request->validate([
        'email' => ['required', 'email'],
        'password' => ['required'],
    ]);

    if (!Auth::attempt($credentials)) {
        return response()->json(['message' => 'Credencials incorrectes'], 401);
    }

    $request->session()->regenerate();

    $user = Auth::user();

    return response()->json([
        'id' => $user->id,
        'name' => $user->name, // 👈 CLAVE
        'email' => $user->email,
        'role' => $user->role ?? 'user'
    ]);
});

Route::post('/logout', function (Request $request) {
    Auth::logout();
    $request->session()->invalidate();
    $request->session()->regenerateToken();

    return response()->json(['message' => 'Logout OK']);
});

Route::get('/user', function (Request $request) {
    return response()->json($request->user());
});

Route::get('/products/search', [ProductosController::class, 'search']);
Route::get('/marcas', [MarcaApiController::class, 'index']);
Route::get('/moviles', [MovilApiController::class, 'index']);

Route::get('/products/{id}', [MovilApiController::class, 'show']);

//cerca de models
Route::get('/models', [ModeloApiController::class, 'index']);
Route::get('/models/search', [ModeloApiController::class, 'search']);
Route::get('/models/{id}', [ModeloApiController::class, 'show']);
Route::get('/models/{model}/options', [ModeloApiController::class, 'options']);
Route::get('/models/{model}/price', [ModeloApiController::class, 'price']);

Route::middleware(['web'])->group(function () {
    Route::get('/carrito', [CarritoApiController::class, 'index']);
    Route::post('/carrito', [CarritoApiController::class, 'store']);
    Route::patch('/carrito/{movil_id}', [CarritoApiController::class, 'update']);
    Route::delete('/carrito/{movil_id}', [CarritoApiController::class, 'destroy']);
    Route::delete('/carrito/vaciar', [CarritoApiController::class, 'clear']);
});

Route::prefix('checkout')->middleware(['web', 'auth:sanctum'])->group(function () {
    Route::post('/intent',  [CheckoutApiController::class, 'createIntent']);
    Route::post('/confirm', [CheckoutApiController::class, 'confirm']);
});

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/checkout/intent', [CheckoutApiController::class, 'createIntent']);
    Route::post('/checkout/confirm', [CheckoutApiController::class, 'confirm']);
});

//imagenes de modelos
Route::post('/models/upload-image', [ModeloApiController::class, 'uploadImage']);
Route::get('/models/{id}/images', [ModeloApiController::class, 'images']);
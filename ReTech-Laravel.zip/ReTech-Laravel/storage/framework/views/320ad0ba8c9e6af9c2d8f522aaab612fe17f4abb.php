<div
    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'filament-notifications-title flex h-6 items-center text-sm font-medium text-gray-900',
        'dark:text-gray-100' => config('notifications.dark_mode'),
    ]) ?>"
>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/omar/Documents/Retech/ReTech-Laravel/vendor/filament/notifications/resources/views/components/title.blade.php ENDPATH**/ ?>
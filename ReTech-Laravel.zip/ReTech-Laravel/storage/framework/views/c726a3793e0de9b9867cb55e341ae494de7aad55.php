<td
    <?php echo e($attributes->class(['filament-tables-reorder-cell w-4 px-4 whitespace-nowrap'])); ?>

>
    <?php echo e($slot); ?>

</td>
<?php /**PATH /Users/omar/Documents/Retech/ReTech-Laravel/vendor/filament/tables/resources/views/components/reorder/cell.blade.php ENDPATH**/ ?>
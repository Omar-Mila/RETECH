<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH /Users/omar/Documents/Retech/ReTech-Laravel/vendor/filament/forms/resources/views/components/group.blade.php ENDPATH**/ ?>
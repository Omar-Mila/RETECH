<td <?php echo e($attributes->class(['w-full px-4 py-4 animate-pulse'])); ?>>
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'h-4 bg-gray-300 rounded-md',
        'dark:bg-gray-600' => config('tables.dark_mode'),
    ]) ?>"></div>
</td>
<?php /**PATH /Users/omar/Documents/Retech/ReTech-Laravel/vendor/filament/tables/resources/views/components/loading-cell.blade.php ENDPATH**/ ?>
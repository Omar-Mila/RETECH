<div class="filament-resource-relation-manager">
    <?php echo e($this->table); ?>

</div>
<?php /**PATH /Users/omar/Documents/Retech/ReTech-Laravel/vendor/filament/filament/resources/views/resources/relation-manager.blade.php ENDPATH**/ ?>
<td
    <?php echo e($attributes->class([
        'filament-tables-cell',
        'dark:text-white' => config('tables.dark_mode'),
    ])); ?>

>
    <?php echo e($slot); ?>

</td>
<?php /**PATH /Users/omar/Documents/Retech/ReTech-Laravel/vendor/filament/tables/resources/views/components/cell.blade.php ENDPATH**/ ?>
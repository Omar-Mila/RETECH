<h2 <?php echo e($attributes->class([
    'filament-tables-empty-state-heading text-xl font-bold tracking-tight',
    'dark:text-white' => config('tables.dark_mode'),
])); ?>>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH /Users/omar/Documents/Retech/ReTech-Laravel/vendor/filament/tables/resources/views/components/empty-state/heading.blade.php ENDPATH**/ ?>